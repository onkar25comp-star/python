# Application Configuration
APP_NAME = "QuizMaster Pro"
APP_VERSION = "2.0"
WINDOW_WIDTH = 1400
WINDOW_HEIGHT = 900
BG_COLOR = "#2C3E50"
ACCENT_COLOR = "#3498DB"
SUCCESS_COLOR = "#27AE60"
ERROR_COLOR = "#E74C3C"

# Database Configuration
DB_NAME = "database/quiz_database.db"

# Age Groups
AGE_GROUP_KIDS = "kids"
AGE_GROUP_ADULTS = "adults"

# Difficulty Levels
DIFFICULTY_EASY = "easy"
DIFFICULTY_MEDIUM = "medium"
DIFFICULTY_HARD = "hard"

# Modern Color Scheme
COLORS = {
    "primary": "#3498DB",      # Blue
    "secondary": "#2C3E50",    # Dark Blue
    "success": "#27AE60",      # Green
    "warning": "#F39C12",      # Orange
    "danger": "#E74C3C",       # Red
    "light": "#ECF0F1",        # Light Gray
    "dark": "#34495E",         # Dark Gray
    "accent": "#9B59B6"        # Purple
}
