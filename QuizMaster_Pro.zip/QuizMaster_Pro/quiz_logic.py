import sqlite3
import time
from database import DatabaseManager
from config import *

class QuizManager:
    def __init__(self):
        self.db = DatabaseManager()
        self.current_quiz = None
        self.current_question_index = 0
        self.score = 0
        self.correct_answers = 0
        self.total_questions = 0
        self.current_streak = 0
        self.max_streak = 0
        self.start_time = None
        self.achievement_manager = AchievementManager()
    
    def start_new_quiz(self, user_id, category_id, difficulty=None, question_limit=10):
        """Start a new quiz session"""
        questions = self.db.get_questions_by_category(category_id, difficulty, question_limit)
        
        if not questions:
            return 0
        
        self.current_quiz = {
            'user_id': user_id,
            'category_id': category_id,
            'difficulty': difficulty,
            'questions': questions,
            'user_answers': [],
            'start_time': time.time(),
            'end_time': None
        }
        
        self.current_question_index = 0
        self.score = 0
        self.correct_answers = 0
        self.total_questions = len(questions)
        self.current_streak = 0
        self.max_streak = 0
        self.start_time = time.time()
        
        return self.total_questions
    
    def get_current_question(self):
        """Get the current question data"""
        if not self.current_quiz or self.current_question_index >= len(self.current_quiz['questions']):
            return None
        
        question_data = self.current_quiz['questions'][self.current_question_index]
        return {
            'id': question_data[0],
            'question_text': question_data[2],
            'options': [question_data[3], question_data[4], question_data[5], question_data[6]],
            'correct_option': question_data[7],
            'difficulty': question_data[8],
            'explanation': question_data[10]
        }
    
    def submit_answer(self, selected_option):
        """Submit answer for current question and move to next"""
        if not self.current_quiz:
            return False
        
        current_question = self.get_current_question()
        is_correct = (selected_option == current_question['correct_option'])
        
        # Update stats
        if is_correct:
            self.correct_answers += 1
            self.current_streak += 1
            self.max_streak = max(self.max_streak, self.current_streak)
            
            # Calculate score based on difficulty
            score_points = self._calculate_score_points(current_question['difficulty'])
            self.score += score_points
        else:
            self.current_streak = 0
        
        # Store user answer
        self.current_quiz['user_answers'].append({
            'question_id': current_question['id'],
            'selected_option': selected_option,
            'is_correct': is_correct,
            'question_data': current_question
        })
        
        # Move to next question
        self.current_question_index += 1
        
        return {
            'is_correct': is_correct,
            'correct_answer': current_question['correct_option'],
            'explanation': current_question['explanation'],
            'current_score': self.score,
            'progress': self.get_quiz_progress(),
            'current_streak': self.current_streak
        }
    
    def _calculate_score_points(self, difficulty):
        """Calculate points based on question difficulty"""
        points = {
            DIFFICULTY_EASY: 10,
            DIFFICULTY_MEDIUM: 20,
            DIFFICULTY_HARD: 30
        }
        return points.get(difficulty, 10)
    
    def get_quiz_progress(self):
        """Get current quiz progress percentage"""
        if not self.current_quiz:
            return 0
        return (self.current_question_index / len(self.current_quiz['questions'])) * 100
    
    def get_question_number(self):
        """Get current question number"""
        return self.current_question_index
    
    def is_quiz_completed(self):
        """Check if quiz is completed"""
        if not self.current_quiz:
            return True
        return self.current_question_index >= len(self.current_quiz['questions'])
    
    def get_quiz_results(self):
        """Get final quiz results"""
        if not self.is_quiz_completed():
            return None
        
        accuracy = (self.correct_answers / self.total_questions) * 100 if self.total_questions > 0 else 0
        time_taken = time.time() - self.start_time if self.start_time else 0
        
        return {
            'total_questions': self.total_questions,
            'correct_answers': self.correct_answers,
            'score': self.score,
            'accuracy': accuracy,
            'max_streak': self.max_streak,
            'time_taken': time_taken,
            'user_answers': self.current_quiz['user_answers']
        }
    
    def save_quiz_results(self):
        """Save quiz results to database and check achievements"""
        if not self.current_quiz or not self.is_quiz_completed():
            return False, []
        
        results = self.get_quiz_results()
        
        conn = self.db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO user_scores 
            (user_id, category_id, score, total_questions, time_taken)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            self.current_quiz['user_id'],
            self.current_quiz['category_id'],
            results['score'],
            results['total_questions'],
            results['time_taken']
        ))
        
        score_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Check for achievements
        unlocked_achievements = self._check_achievements(results)
        
        return True, unlocked_achievements
    
    def _check_achievements(self, results):
        """Check and unlock achievements after quiz completion"""
        unlocked = self.achievement_manager.check_quiz_completion_achievements(
            self.current_quiz['user_id'], 
            {
                **results, 
                'category_id': self.current_quiz['category_id'],
                'difficulty': self.current_quiz['difficulty']
            }
        )
        
        # Check streak achievements
        unlocked.extend(
            self.achievement_manager.check_streak_achievements(
                self.current_quiz['user_id'], 
                results['max_streak']
            )
        )
        
        return unlocked
    
    def skip_question(self):
        """Skip current question without answering"""
        if not self.current_quiz:
            return False
        
        current_question = self.get_current_question()
        
        # Store as incorrect answer
        self.current_quiz['user_answers'].append({
            'question_id': current_question['id'],
            'selected_option': 0,  # 0 indicates skipped
            'is_correct': False,
            'question_data': current_question
        })
        
        self.current_question_index += 1
        self.current_streak = 0
        
        return True

class AchievementManager:
    def __init__(self):
        self.db = DatabaseManager()
    
    def check_quiz_completion_achievements(self, user_id, score_data):
        """Check achievements related to quiz completion"""
        unlocked_achievements = []
        
        # Get user's age group
        user = self._get_user(user_id)
        if not user:
            return unlocked_achievements
        
        age_group = user[3]
        
        # Check for first quiz completion
        quiz_count = self._get_user_quiz_count(user_id)
        if quiz_count == 1:
            achievement = self._get_achievement_by_condition("quiz_complete", 1, age_group)
            if achievement and self._unlock_achievement(user_id, achievement[0]):
                unlocked_achievements.append(achievement)
        
        # Check for high score achievement
        if score_data['accuracy'] >= 90:
            achievement = self._get_achievement_by_condition("high_score", 90, age_group)
            if achievement and self._unlock_achievement(user_id, achievement[0]):
                unlocked_achievements.append(achievement)
        
        # Check for perfect score in category
        if score_data['accuracy'] == 100:
            achievement = self._get_achievement_by_condition("category_perfect", score_data['category_id'], age_group)
            if achievement and self._unlock_achievement(user_id, achievement[0]):
                unlocked_achievements.append(achievement)
        
        # Check for perfect hard difficulty
        if score_data['accuracy'] == 100 and score_data.get('difficulty') == DIFFICULTY_HARD:
            achievement = self._get_achievement_by_condition("perfect_hard", 1, age_group)
            if achievement and self._unlock_achievement(user_id, achievement[0]):
                unlocked_achievements.append(achievement)
        
        # Check category completion
        achievement = self._get_achievement_by_condition("category_complete", score_data['category_id'], age_group)
        if achievement and self._unlock_achievement(user_id, achievement[0]):
            unlocked_achievements.append(achievement)
        
        return unlocked_achievements
    
    def check_streak_achievements(self, user_id, max_streak):
        """Check achievements related to answer streaks"""
        unlocked_achievements = []
        
        user = self._get_user(user_id)
        if not user:
            return unlocked_achievements
        
        age_group = user[3]
        
        # Check streak achievements
        achievements = self._get_achievements_by_type("streak", age_group)
        for achievement in achievements:
            if max_streak >= achievement[5]:
                if self._unlock_achievement(user_id, achievement[0]):
                    unlocked_achievements.append(achievement)
        
        return unlocked_achievements
    
    def _get_user(self, user_id):
        """Get user data by ID"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        conn.close()
        return user
    
    def _get_user_quiz_count(self, user_id):
        """Get total number of quizzes completed by user"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM user_scores WHERE user_id = ?", (user_id,))
        count = cursor.fetchone()[0]
        conn.close()
        return count
    
    def _get_achievement_by_condition(self, condition_type, condition_value, age_group):
        """Get achievement by condition type and value"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM achievements WHERE condition_type = ? AND condition_value <= ? AND age_group = ?",
            (condition_type, condition_value, age_group)
        )
        achievement = cursor.fetchone()
        conn.close()
        return achievement
    
    def _get_achievements_by_type(self, condition_type, age_group):
        """Get all achievements of a specific type"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM achievements WHERE condition_type = ? AND age_group = ? ORDER BY condition_value DESC",
            (condition_type, age_group)
        )
        achievements = cursor.fetchall()
        conn.close()
        return achievements
    
    def _unlock_achievement(self, user_id, achievement_id):
        """Unlock an achievement for a user"""
        # Check if already unlocked
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM user_achievements WHERE user_id = ? AND achievement_id = ?",
            (user_id, achievement_id)
        )
        already_unlocked = cursor.fetchone()
        
        if already_unlocked:
            conn.close()
            return False
        
        # Unlock achievement
        cursor.execute(
            "INSERT INTO user_achievements (user_id, achievement_id) VALUES (?, ?)",
            (user_id, achievement_id)
        )
        conn.commit()
        conn.close()
        return True
    
    def get_user_achievements(self, user_id):
        """Get all achievements for a user (unlocked and locked)"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        
        # Get unlocked achievements
        cursor.execute('''
            SELECT a.*, ua.unlocked_at 
            FROM achievements a 
            JOIN user_achievements ua ON a.id = ua.achievement_id 
            WHERE ua.user_id = ?
        ''', (user_id,))
        unlocked = cursor.fetchall()
        
        # Get all possible achievements for user's age group
        user = self._get_user(user_id)
        age_group = user[3] if user else "adults"
        
        cursor.execute(
            "SELECT * FROM achievements WHERE age_group = ?",
            (age_group,)
        )
        all_achievements = cursor.fetchall()
        
        conn.close()
        
        # Separate locked achievements
        unlocked_ids = [ach[0] for ach in unlocked]
        locked = [ach for ach in all_achievements if ach[0] not in unlocked_ids]
        
        return {
            'unlocked': unlocked,
            'locked': locked
        }

class UserManager:
    def __init__(self):
        self.db = DatabaseManager()
        self.current_user = None
    
    def register_user(self, username, password, age_group):
        """Register a new user"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                "INSERT INTO users (username, password, age_group) VALUES (?, ?, ?)",
                (username, password, age_group)
            )
            user_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            self.current_user = self.get_user_by_id(user_id)
            return True, "Registration successful!"
            
        except sqlite3.IntegrityError:
            conn.close()
            return False, "Username already exists!"
        except Exception as e:
            conn.close()
            return False, f"Registration failed: {str(e)}"
    
    def login_user(self, username, password):
        """Login user"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            (username, password)
        )
        user = cursor.fetchone()
        conn.close()
        
        if user:
            self.current_user = user
            return True, "Login successful!"
        else:
            return False, "Invalid username or password!"
    
    def logout_user(self):
        """Logout current user"""
        self.current_user = None
    
    def get_user_by_id(self, user_id):
        """Get user by ID"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        conn.close()
        return user
    
    def get_user_stats(self, user_id):
        """Get user statistics"""
        conn = self.db.get_connection()
        cursor = conn.cursor()
        
        # Total quizzes
        cursor.execute("SELECT COUNT(*) FROM user_scores WHERE user_id = ?", (user_id,))
        total_quizzes = cursor.fetchone()[0]
        
        # Total score
        cursor.execute("SELECT SUM(score) FROM user_scores WHERE user_id = ?", (user_id,))
        total_score = cursor.fetchone()[0] or 0
        
        # Average accuracy
        cursor.execute('''
            SELECT AVG(CAST(correct_answers AS FLOAT) / CAST(total_questions AS FLOAT) * 100) 
            FROM (
                SELECT score, total_questions, 
                       CAST(score AS FLOAT) / 10 AS correct_answers 
                FROM user_scores WHERE user_id = ?
            )
        ''', (user_id,))
        avg_accuracy = cursor.fetchone()[0] or 0
        
        # Total questions answered
        cursor.execute("SELECT SUM(total_questions) FROM user_scores WHERE user_id = ?", (user_id,))
        total_questions = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return {
            'total_quizzes': total_quizzes,
            'total_score': total_score,
            'average_accuracy': round(avg_accuracy, 2),
            'total_questions': total_questions
        }
