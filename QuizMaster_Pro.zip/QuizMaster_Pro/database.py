import sqlite3
import os
from config import DB_NAME

class DatabaseManager:
    def __init__(self):
        self.db_path = DB_NAME
        self.create_tables()
        self.insert_sample_data()
    
    def get_connection(self):
        """Create database connection"""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        return sqlite3.connect(self.db_path)
    
    def create_tables(self):
        """Create all necessary tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Categories table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                age_group TEXT NOT NULL,
                icon_path TEXT
            )
        ''')
        
        # Questions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER,
                question_text TEXT NOT NULL,
                option1 TEXT NOT NULL,
                option2 TEXT NOT NULL,
                option3 TEXT NOT NULL,
                option4 TEXT NOT NULL,
                correct_option INTEGER NOT NULL,
                difficulty TEXT NOT NULL,
                age_group TEXT NOT NULL,
                explanation TEXT,
                FOREIGN KEY (category_id) REFERENCES categories (id)
            )
        ''')
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                age_group TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Achievements table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                icon_path TEXT,
                condition_type TEXT NOT NULL,
                condition_value INTEGER NOT NULL,
                age_group TEXT NOT NULL
            )
        ''')
        
        # User scores table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                category_id INTEGER,
                score INTEGER NOT NULL,
                total_questions INTEGER NOT NULL,
                time_taken INTEGER,
                completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (category_id) REFERENCES categories (id)
            )
        ''')
        
        # User achievements table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                achievement_id INTEGER,
                unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (achievement_id) REFERENCES achievements (id)
            )
        ''')
        
        conn.commit()
        conn.close()

    def insert_sample_data(self):
        """Insert comprehensive sample data with 30 questions per category"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Clear existing data
        cursor.execute("DELETE FROM user_achievements")
        cursor.execute("DELETE FROM user_scores")
        cursor.execute("DELETE FROM achievements")
        cursor.execute("DELETE FROM questions")
        cursor.execute("DELETE FROM categories")
        cursor.execute("DELETE FROM users")
        
        # Insert categories in exact order
        categories = [
            # Kids categories (IDs 1-4)
            (1, "Animals", "Learn about amazing animals!", "kids", "images/animals_icon.png"),
            (2, "Cartoons", "Fun questions about cartoons!", "kids", "images/cartoons_icon.png"),
            (3, "Science Fun", "Easy science questions", "kids", "images/science_icon.png"),
            (4, "General Knowledge", "Fun facts for kids", "kids", "images/kids_icon.png"),
            
            # Adults categories (IDs 5-8)
            (5, "Technology", "Latest tech and innovations", "adults", "images/tech_icon.png"),
            (6, "History", "World history and events", "adults", "images/history_icon.png"),
            (7, "Business", "Business and economics", "adults", "images/business_icon.png"),
            (8, "Current Affairs", "Recent events and news", "adults", "images/adults_icon.png"),
        ]
        
        # Insert with explicit IDs to ensure consistency
        for cat_id, name, description, age_group, icon_path in categories:
            cursor.execute(
                "INSERT INTO categories (id, name, description, age_group, icon_path) VALUES (?, ?, ?, ?, ?)",
                (cat_id, name, description, age_group, icon_path)
            )
        
        # Insert 240 questions (30 per category)
        questions = self._get_all_questions()
        cursor.executemany('''
            INSERT INTO questions 
            (category_id, question_text, option1, option2, option3, option4, correct_option, difficulty, age_group, explanation) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', questions)
        
        # Insert achievements
        achievements = [
            # Kids achievements
            ("First Star", "Complete your first quiz", "images/achievement_icons/first_star.png", "quiz_complete", 1, "kids"),
            ("Animal Expert", "Score 100% in Animals category", "images/achievement_icons/animal_expert.png", "category_perfect", 1, "kids"),
            ("Quick Learner", "Answer 5 questions correctly in a row", "images/achievement_icons/quick_learner.png", "streak", 5, "kids"),
            ("Science Whiz", "Complete Science Fun category", "images/achievement_icons/quick_learner.png", "category_complete", 3, "kids"),
            ("Cartoon Fan", "Answer 10 cartoon questions", "images/achievement_icons/first_star.png", "total_questions", 10, "kids"),
            
            # Adults achievements
            ("Brainiac", "Score 90%+ in any category", "images/achievement_icons/brainiac.png", "high_score", 90, "adults"),
            ("Marathon Runner", "Complete 50 questions total", "images/achievement_icons/marathon.png", "total_questions", 50, "adults"),
            ("Perfectionist", "Get 100% on Hard difficulty", "images/achievement_icons/perfectionist.png", "perfect_hard", 1, "adults"),
            ("History Buff", "Master History category", "images/achievement_icons/brainiac.png", "category_complete", 6, "adults"),
            ("Tech Guru", "Score 100% in Technology", "images/achievement_icons/perfectionist.png", "category_perfect", 5, "adults"),
        ]
        
        cursor.executemany('''
            INSERT INTO achievements 
            (name, description, icon_path, condition_type, condition_value, age_group) 
            VALUES (?, ?, ?, ?, ?, ?)
        ''', achievements)
        
        # Insert sample users
        sample_users = [
            ("kid_user", "1234", "kids"),
            ("adult_user", "1234", "adults"),
            ("test", "test", "adults")
        ]
        
        cursor.executemany(
            "INSERT INTO users (username, password, age_group) VALUES (?, ?, ?)",
            sample_users
        )
        
        conn.commit()
        conn.close()
        
        print("✅ Database created successfully!")
        print("✅ 240 questions inserted (30 per category)")
        print("✅ Test accounts created:")
        print("   Kids Mode: kid_user / 1234")
        print("   Adults Mode: adult_user / 1234")
        print("   Test Account: test / test")

    def _get_all_questions(self):
        """Return 240 questions (30 for each of the 8 categories)"""
        return [
            # Category 1: Animals (Kids) - 30 questions
            (1, "What animal is known as the 'King of the Jungle'?", "Elephant", "Lion", "Tiger", "Bear", 2, "easy", "kids", "Lion is called the King of the Jungle!"),
            (1, "Which animal can change its color?", "Rabbit", "Chameleon", "Dog", "Cat", 2, "easy", "kids", "Chameleons can change color to blend in."),
            (1, "What is the largest mammal in the world?", "Elephant", "Giraffe", "Blue Whale", "Polar Bear", 3, "easy", "kids", "Blue Whale is the largest mammal."),
            (1, "Which bird can't fly but can swim very well?", "Eagle", "Sparrow", "Penguin", "Owl", 3, "easy", "kids", "Penguins are flightless birds that swim."),
            (1, "How many legs does a spider have?", "6", "8", "10", "4", 2, "easy", "kids", "Spiders have 8 legs."),
            (1, "What do bees collect from flowers?", "Water", "Nectar", "Leaves", "Seeds", 2, "easy", "kids", "Bees collect nectar to make honey."),
            (1, "Which animal sleeps upside down?", "Bat", "Bird", "Squirrel", "Rabbit", 1, "easy", "kids", "Bats sleep hanging upside down."),
            (1, "What is a baby cat called?", "Puppy", "Cub", "Kitten", "Chick", 3, "easy", "kids", "A baby cat is called a kitten."),
            (1, "Which animal has a trunk?", "Elephant", "Giraffe", "Rhino", "Hippo", 1, "easy", "kids", "Elephants have long trunks."),
            (1, "What do caterpillars turn into?", "Birds", "Butterflies", "Bees", "Spiders", 2, "easy", "kids", "Caterpillars become butterflies."),
            (1, "Which animal is the fastest land animal?", "Lion", "Cheetah", "Horse", "Deer", 2, "medium", "kids", "Cheetahs can run up to 70 mph!"),
            (1, "What do frogs start their life as?", "Eggs", "Tadpoles", "Mini frogs", "Caterpillars", 2, "medium", "kids", "Frogs begin as tadpoles."),
            (1, "Which animal has black and white stripes?", "Tiger", "Zebra", "Leopard", "Giraffe", 2, "medium", "kids", "Zebras have distinctive stripes."),
            (1, "What is a group of lions called?", "Herd", "Pack", "Pride", "Flock", 3, "medium", "kids", "A group of lions is a pride."),
            (1, "Which bird has the largest wingspan?", "Eagle", "Albatross", "Ostrich", "Peacock", 2, "medium", "kids", "Albatross has the largest wingspan."),
            (1, "What is the only mammal that can fly?", "Bat", "Bird", "Flying squirrel", "Butterfly", 1, "medium", "kids", "Bats are flying mammals."),
            (1, "Which animal is known for playing dead?", "Rabbit", "Opossum", "Squirrel", "Raccoon", 2, "medium", "kids", "Opossums play dead when scared."),
            (1, "What do you call a baby bear?", "Cub", "Pup", "Kitten", "Calf", 1, "easy", "kids", "Baby bears are called cubs."),
            (1, "Which animal has the longest neck?", "Elephant", "Giraffe", "Camel", "Ostrich", 2, "easy", "kids", "Giraffes have the longest necks."),
            (1, "What do snakes use to smell?", "Nose", "Tongue", "Ears", "Skin", 2, "medium", "kids", "Snakes use their tongues to smell."),
            (1, "Which animal can regrow its tail?", "Dog", "Cat", "Lizard", "Rabbit", 3, "medium", "kids", "Lizards can regrow their tails."),
            (1, "What is a female deer called?", "Doe", "Buck", "Fawn", "Hind", 1, "medium", "kids", "A female deer is a doe."),
            (1, "Which animal is the national bird of USA?", "Eagle", "Robin", "Sparrow", "Owl", 1, "medium", "kids", "Bald Eagle is USA's national bird."),
            (1, "What do kangaroos keep in their pouch?", "Food", "Babies", "Water", "Rocks", 2, "easy", "kids", "Kangaroos carry babies in pouch."),
            (1, "Which animal is known as 'man's best friend'?", "Cat", "Dog", "Horse", "Rabbit", 2, "easy", "kids", "Dogs are called man's best friend."),
            (1, "What color is a polar bear's skin?", "White", "Black", "Pink", "Brown", 2, "hard", "kids", "Polar bears have black skin under white fur."),
            (1, "Which bird can mimic human speech?", "Eagle", "Parrot", "Crow", "Sparrow", 2, "medium", "kids", "Parrots can mimic human speech."),
            (1, "How many hearts does an octopus have?", "1", "2", "3", "4", 3, "hard", "kids", "Octopuses have 3 hearts!"),
            (1, "Which animal is the symbol of wisdom?", "Fox", "Owl", "Elephant", "Dolphin", 2, "medium", "kids", "Owls symbolize wisdom."),
            (1, "What is the smallest bird in the world?", "Sparrow", "Hummingbird", "Finch", "Robin", 2, "medium", "kids", "Bee hummingbird is the smallest."),

            # Category 2: Cartoons (Kids) - 30 questions
            (2, "What is the name of the sponge who lives in a pineapple?", "Patrick", "Squidward", "SpongeBob", "Mr. Krabs", 3, "easy", "kids", "SpongeBob SquarePants!"),
            (2, "Which character lives in a trash can on Sesame Street?", "Big Bird", "Elmo", "Oscar", "Cookie Monster", 3, "easy", "kids", "Oscar the Grouch lives in a trash can."),
            (2, "What type of animal is Mickey Mouse?", "Dog", "Cat", "Mouse", "Rabbit", 3, "easy", "kids", "Mickey is a mouse!"),
            (2, "What is the name of the boy in 'Up' who joins Carl?", "Russell", "Kevin", "Doug", "Tom", 1, "easy", "kids", "The boy's name is Russell."),
            (2, "Which superhero can climb walls like a spider?", "Batman", "Superman", "Spider-Man", "Iron Man", 3, "easy", "kids", "Spider-Man can climb walls."),
            (2, "What is the name of the ice princess in Frozen?", "Anna", "Elsa", "Olaf", "Rapunzel", 2, "easy", "kids", "Elsa has ice powers."),
            (2, "Which cartoon character loves to eat lasagna?", "Scooby-Doo", "Garfield", "Tom", "Jerry", 2, "easy", "kids", "Garfield the cat loves lasagna."),
            (2, "What is the name of the dragon in Mulan?", "Mushu", "Toothless", "Smaug", "Falkor", 1, "easy", "kids", "Mushu is Mulan's dragon."),
            (2, "Which cartoon features a talking dog who solves mysteries?", "Scooby-Doo", "Paw Patrol", "Bluey", "Peppa Pig", 1, "easy", "kids", "Scooby-Doo and friends solve mysteries."),
            (2, "What is the name of the little fish in Finding Nemo?", "Dory", "Nemo", "Marlin", "Bruce", 2, "easy", "kids", "Nemo is the little clownfish."),
            (2, "Which character says 'To infinity and beyond!'?", "Buzz Lightyear", "Woody", "Mr. Potato Head", "Rex", 1, "medium", "kids", "Buzz Lightyear's famous line!"),
            (2, "What is the name of the princess in The Little Mermaid?", "Ariel", "Jasmine", "Belle", "Cinderella", 1, "medium", "kids", "Ariel is the little mermaid."),
            (2, "Which cartoon features a boy with a magical remote?", "Fairly OddParents", "Jimmy Neutron", "Ben 10", "Adventure Time", 1, "medium", "kids", "Timmy Turner has fairy godparents."),
            (2, "What is the name of the robot in Transformers who turns into a truck?", "Bumblebee", "Optimus Prime", "Megatron", "Starscream", 2, "medium", "kids", "Optimus Prime is the leader."),
            (2, "Which cartoon character lives in a pineapple under the sea?", "Patrick Star", "Sandy Cheeks", "SpongeBob", "Squidward", 3, "medium", "kids", "SpongeBob SquarePants!"),
            (2, "What is the name of the superhero family in The Incredibles?", "The Supers", "The Incredibles", "The Parrs", "The Heroes", 2, "easy", "kids", "They are called The Incredibles."),
            (2, "Which cartoon features a boy who can turn into aliens?", "Ben 10", "Generator Rex", "Danny Phantom", "American Dragon", 1, "medium", "kids", "Ben 10 uses the Omnitrix."),
            (2, "What is the name of the yellow minions in Despicable Me?", "Bob", "Kevin", "Stuart", "All of them", 4, "easy", "kids", "Minions have different names."),
            (2, "Which cartoon character is a fast blue hedgehog?", "Mario", "Sonic", "Pikachu", "Mickey", 2, "easy", "kids", "Sonic the Hedgehog is blue and fast."),
            (2, "What is the name of the cowboy in Toy Story?", "Buzz", "Woody", "Rex", "Hamm", 2, "easy", "kids", "Woody is the cowboy doll."),
            (2, "Which cartoon features a talking cat and dog?", "Tom and Jerry", "Garfield", "Pink Panther", "Scooby-Doo", 1, "easy", "kids", "Tom and Jerry are famous rivals."),
            (2, "What is the name of the princess in Beauty and the Beast?", "Aurora", "Belle", "Cinderella", "Snow White", 2, "easy", "kids", "Belle is the beauty."),
            (2, "Which cartoon character lives in a water bowl?", "Nemo", "Dory", "Flounder", "None", 4, "medium", "kids", "Fish don't live in water bowls in cartoons."),
            (2, "What is the name of the little robot in Star Wars cartoons?", "C-3PO", "R2-D2", "BB-8", "D-O", 2, "medium", "kids", "R2-D2 is the beeping robot."),
            (2, "Which cartoon features a boy with a magic treehouse?", "Magic Tree House", "Adventure Time", "Regular Show", "The Amazing World of Gumball", 1, "medium", "kids", "Jack and Annie use a magic treehouse."),
            (2, "What is the name of the princess in Aladdin?", "Jasmine", "Ariel", "Belle", "Pocahontas", 1, "easy", "kids", "Princess Jasmine marries Aladdin."),
            (2, "Which cartoon character is a pink puffball?", "Kirby", "Jigglypuff", "Pink Panther", "My Melody", 1, "medium", "kids", "Kirby is a pink puffball character."),
            (2, "What is the name of the dinosaur in The Good Dinosaur?", "Rex", "Tiny", "Arlo", "Sully", 3, "medium", "kids", "Arlo is the main character."),
            (2, "Which cartoon features a talking horse?", "BoJack Horseman", "Mr. Ed", "My Little Pony", "All of them", 4, "hard", "kids", "All these have talking horses."),
            (2, "What is the name of the ice age squirrel?", "Scrat", "Sid", "Diego", "Manny", 1, "easy", "kids", "Scrat is always chasing acorns."),

            # Category 3: Science Fun (Kids) - 30 questions
            (3, "What planet do we live on?", "Mars", "Earth", "Jupiter", "Venus", 2, "easy", "kids", "We live on planet Earth."),
            (3, "What do plants need to make their food?", "Water", "Sunlight", "Soil", "All of these", 4, "easy", "kids", "Plants need water, sunlight, and soil."),
            (3, "What is H2O also known as?", "Air", "Water", "Fire", "Earth", 2, "easy", "kids", "H2O is the chemical formula for water."),
            (3, "Which of these is NOT a season?", "Summer", "Winter", "Christmas", "Spring", 3, "easy", "kids", "Christmas is a holiday, not a season."),
            (3, "What do you call a baby dog?", "Kitten", "Puppy", "Cub", "Chick", 2, "easy", "kids", "A baby dog is called a puppy."),
            (3, "How many colors are in a rainbow?", "5", "6", "7", "8", 3, "easy", "kids", "Rainbows have 7 colors: ROYGBIV."),
            (3, "What is the closest star to Earth?", "Sun", "Moon", "Mars", "Venus", 1, "easy", "kids", "The Sun is our closest star."),
            (3, "Which of these is a source of light?", "Sun", "Moon", "Both", "None", 1, "easy", "kids", "The Sun produces its own light."),
            (3, "What do bees make?", "Honey", "Milk", "Juice", "Water", 1, "easy", "kids", "Bees make honey from nectar."),
            (3, "Which sense do you use with your eyes?", "Hearing", "Sight", "Smell", "Taste", 2, "easy", "kids", "Eyes are for seeing."),
            (3, "What is the largest planet in our solar system?", "Earth", "Jupiter", "Saturn", "Mars", 2, "medium", "kids", "Jupiter is the largest planet."),
            (3, "What gas do plants breathe in?", "Oxygen", "Carbon Dioxide", "Nitrogen", "Helium", 2, "medium", "kids", "Plants take in carbon dioxide."),
            (3, "How many bones are in the human body?", "106", "206", "306", "406", 2, "medium", "kids", "Adults have 206 bones."),
            (3, "What is the hardest natural substance?", "Gold", "Diamond", "Iron", "Platinum", 2, "medium", "kids", "Diamond is the hardest natural material."),
            (3, "Which of these is a renewable energy source?", "Coal", "Solar", "Oil", "Gas", 2, "medium", "kids", "Solar power is renewable."),
            (3, "What do you call a scientist who studies rocks?", "Biologist", "Geologist", "Astronomer", "Chemist", 2, "medium", "kids", "Geologists study rocks and Earth."),
            (3, "Which planet is known as the Red Planet?", "Venus", "Mars", "Jupiter", "Saturn", 2, "easy", "kids", "Mars is called the Red Planet."),
            (3, "What is the main gas in the air we breathe?", "Oxygen", "Carbon Dioxide", "Nitrogen", "Helium", 3, "medium", "kids", "Air is 78% nitrogen."),
            (3, "Which animal can live both in water and on land?", "Fish", "Frog", "Bird", "Lizard", 2, "easy", "kids", "Frogs are amphibians."),
            (3, "What causes lightning?", "Rain", "Thunder", "Electric charge", "Wind", 3, "medium", "kids", "Lightning is caused by electrical charges."),
            (3, "Which of these is NOT a state of matter?", "Solid", "Liquid", "Gas", "Water", 4, "medium", "kids", "Water is a liquid, not a state."),
            (3, "What do you use to see very small things?", "Telescope", "Microscope", "Binoculars", "Glasses", 2, "easy", "kids", "Microscopes magnify small objects."),
            (3, "Which planet has rings around it?", "Earth", "Mars", "Saturn", "Venus", 3, "easy", "kids", "Saturn has beautiful rings."),
            (3, "What is the fastest land animal?", "Lion", "Cheetah", "Horse", "Deer", 2, "easy", "kids", "Cheetahs can run 70 mph!"),
            (3, "Which of these is a fruit?", "Carrot", "Potato", "Apple", "Onion", 3, "easy", "kids", "Apples are fruits."),
            (3, "What do caterpillars turn into?", "Bees", "Butterflies", "Spiders", "Ants", 2, "easy", "kids", "Caterpillars become butterflies."),
            (3, "Which sense uses the tongue?", "Sight", "Hearing", "Taste", "Smell", 3, "easy", "kids", "Tongue is for tasting."),
            (3, "What is the boiling point of water?", "50°C", "100°C", "150°C", "200°C", 2, "hard", "kids", "Water boils at 100°C."),
            (3, "Which metal is liquid at room temperature?", "Iron", "Gold", "Mercury", "Silver", 3, "hard", "kids", "Mercury is a liquid metal."),
            (3, "What is the study of plants called?", "Zoology", "Botany", "Biology", "Geology", 2, "medium", "kids", "Botany is the study of plants."),

            # Category 4: General Knowledge (Kids) - 30 questions
            (4, "How many days are in a week?", "5", "6", "7", "8", 3, "easy", "kids", "There are 7 days in a week."),
            (4, "What is the color of a school bus?", "Red", "Blue", "Yellow", "Green", 3, "easy", "kids", "School buses are yellow."),
            (4, "Which shape has three sides?", "Circle", "Square", "Triangle", "Rectangle", 3, "easy", "kids", "Triangles have 3 sides."),
            (4, "What do you use to write on paper?", "Pen", "Spoon", "Fork", "Plate", 1, "easy", "kids", "Pens are used for writing."),
            (4, "Which month comes after April?", "March", "May", "June", "July", 2, "easy", "kids", "May comes after April."),
            (4, "What is 2 + 3?", "4", "5", "6", "7", 2, "easy", "kids", "2 + 3 = 5"),
            (4, "Which animal says 'moo'?", "Dog", "Cat", "Cow", "Sheep", 3, "easy", "kids", "Cows say 'moo'."),
            (4, "What do you wear on your feet?", "Hat", "Shoes", "Gloves", "Scarf", 2, "easy", "kids", "Shoes go on your feet."),
            (4, "Which is the coldest season?", "Spring", "Summer", "Fall", "Winter", 4, "easy", "kids", "Winter is the coldest season."),
            (4, "What is the opposite of 'day'?", "Morning", "Night", "Evening", "Noon", 2, "easy", "kids", "Night is the opposite of day."),
            (4, "How many hours are in a day?", "12", "24", "36", "48", 2, "medium", "kids", "There are 24 hours in a day."),
            (4, "Which country is known for pyramids?", "Italy", "Egypt", "China", "India", 2, "medium", "kids", "Egypt has the Great Pyramids."),
            (4, "What is the capital of France?", "London", "Berlin", "Paris", "Rome", 3, "medium", "kids", "Paris is the capital of France."),
            (4, "Which ocean is the largest?", "Atlantic", "Indian", "Pacific", "Arctic", 3, "medium", "kids", "Pacific Ocean is the largest."),
            (4, "How many continents are there?", "5", "6", "7", "8", 3, "medium", "kids", "There are 7 continents."),
            (4, "What is the largest animal in the world?", "Elephant", "Blue Whale", "Giraffe", "Polar Bear", 2, "easy", "kids", "Blue Whale is the largest."),
            (4, "Which fruit is yellow and curved?", "Apple", "Banana", "Orange", "Grape", 2, "easy", "kids", "Bananas are yellow and curved."),
            (4, "What do you call a baby cat?", "Puppy", "Kitten", "Cub", "Chick", 2, "easy", "kids", "Baby cats are kittens."),
            (4, "Which month has Valentine's Day?", "January", "February", "March", "April", 2, "easy", "kids", "Valentine's Day is in February."),
            (4, "What is the color of snow?", "Blue", "White", "Green", "Yellow", 2, "easy", "kids", "Snow is white."),
            (4, "How many letters are in the English alphabet?", "24", "25", "26", "27", 3, "easy", "kids", "There are 26 letters."),
            (4, "Which planet is closest to the Sun?", "Earth", "Venus", "Mercury", "Mars", 3, "medium", "kids", "Mercury is closest to the Sun."),
            (4, "What is the capital of Japan?", "Beijing", "Seoul", "Tokyo", "Bangkok", 3, "medium", "kids", "Tokyo is Japan's capital."),
            (4, "Which bird is a symbol of peace?", "Eagle", "Dove", "Swan", "Peacock", 2, "medium", "kids", "Doves symbolize peace."),
            (4, "What is the main ingredient in bread?", "Sugar", "Flour", "Salt", "Water", 2, "medium", "kids", "Bread is made from flour."),
            (4, "Which country has a maple leaf on its flag?", "USA", "Canada", "UK", "Australia", 2, "medium", "kids", "Canada's flag has a maple leaf."),
            (4, "What is the largest ocean animal?", "Shark", "Blue Whale", "Dolphin", "Octopus", 2, "medium", "kids", "Blue Whale is the largest."),
            (4, "Which month has the fewest days?", "February", "April", "June", "November", 1, "medium", "kids", "February has 28 or 29 days."),
            (4, "What is the color of an emerald?", "Red", "Blue", "Green", "Yellow", 3, "medium", "kids", "Emeralds are green."),
            (4, "Which instrument has black and white keys?", "Guitar", "Piano", "Violin", "Drums", 2, "easy", "kids", "Pianos have black and white keys."),

            # Category 5: Technology (Adults) - 30 questions
            (5, "What does CPU stand for?", "Central Processing Unit", "Computer Personal Unit", "Central Processor Unit", "Central Personal Unit", 1, "easy", "adults", "CPU stands for Central Processing Unit"),
            (5, "Which company created the Python programming language?", "Google", "Microsoft", "Python Foundation", "Guido van Rossum", 4, "easy", "adults", "Python was created by Guido van Rossum"),
            (5, "What does HTML stand for?", "Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Markup Language", "Home Tool Markup Language", 1, "easy", "adults", "HTML: Hyper Text Markup Language"),
            (5, "Which of these is a database management system?", "Java", "MySQL", "HTML", "CSS", 2, "easy", "adults", "MySQL is a popular database system"),
            (5, "What year was the first iPhone released?", "2005", "2007", "2009", "2011", 2, "easy", "adults", "First iPhone was released in 2007"),
            (5, "What does URL stand for?", "Uniform Resource Locator", "Universal Reference Link", "Uniform Reference Locator", "Universal Resource Link", 1, "medium", "adults", "URL: Uniform Resource Locator"),
            (5, "Which protocol is used for secure web browsing?", "HTTP", "FTP", "HTTPS", "SMTP", 3, "medium", "adults", "HTTPS provides secure communication"),
            (5, "What is the main purpose of a firewall?", "Speed up internet", "Block viruses", "Monitor network traffic", "Both 2 and 3", 4, "medium", "adults", "Firewalls monitor and block threats"),
            (5, "Which company developed the Windows operating system?", "Apple", "Microsoft", "IBM", "Google", 2, "easy", "adults", "Microsoft develops Windows"),
            (5, "What does RAM stand for?", "Random Access Memory", "Readily Available Memory", "Random Available Memory", "Read Access Memory", 1, "easy", "adults", "RAM: Random Access Memory"),
            (5, "Which programming language is known for web development?", "Python", "JavaScript", "C++", "Java", 2, "medium", "adults", "JavaScript is essential for web dev"),
            (5, "What does SSD stand for in computing?", "Super Speed Disk", "Solid State Drive", "System Storage Device", "Secure Storage Drive", 2, "medium", "adults", "SSD: Solid State Drive"),
            (5, "Which company owns Android operating system?", "Microsoft", "Apple", "Google", "Samsung", 3, "easy", "adults", "Google owns Android"),
            (5, "What is the purpose of a VPN?", "Increase internet speed", "Provide secure connection", "Block ads", "All of the above", 2, "medium", "adults", "VPN provides secure encrypted connection"),
            (5, "Which of these is a version control system?", "Git", "Docker", "Kubernetes", "Jenkins", 1, "hard", "adults", "Git is a version control system"),
            (5, "What does API stand for?", "Application Programming Interface", "Advanced Programming Interface", "Application Process Integration", "Automated Programming Interface", 1, "medium", "adults", "API: Application Programming Interface"),
            (5, "Which language is used for styling web pages?", "HTML", "JavaScript", "CSS", "Python", 3, "easy", "adults", "CSS is for styling web pages"),
            (5, "What is cloud computing?", "Weather forecasting", "Internet-based computing", "Gaming", "Social media", 2, "medium", "adults", "Cloud computing delivers services over internet"),
            (5, "Which company developed the React library?", "Google", "Facebook", "Microsoft", "Twitter", 2, "hard", "adults", "React was developed by Facebook"),
            (5, "What does IoT stand for?", "Internet of Things", "Integration of Technology", "International Online Trade", "Internet Office Tools", 1, "medium", "adults", "IoT: Internet of Things"),
            (5, "Which programming language is known for data analysis?", "Java", "Python", "C++", "Ruby", 2, "medium", "adults", "Python is popular for data analysis"),
            (5, "What does GUI stand for?", "Graphical User Interface", "General Utility Interface", "Graphic Utility Integration", "General User Interface", 1, "medium", "adults", "GUI: Graphical User Interface"),
            (5, "Which company created the Macintosh computer?", "Microsoft", "IBM", "Apple", "Dell", 3, "easy", "adults", "Apple created Macintosh"),
            (5, "What is the most popular web browser?", "Internet Explorer", "Chrome", "Firefox", "Safari", 2, "easy", "adults", "Google Chrome is most popular"),
            (5, "Which of these is a NoSQL database?", "MySQL", "PostgreSQL", "MongoDB", "SQLite", 3, "hard", "adults", "MongoDB is a NoSQL database"),
            (5, "What does AI stand for?", "Automated Intelligence", "Artificial Intelligence", "Advanced Internet", "Automated Internet", 2, "easy", "adults", "AI: Artificial Intelligence"),
            (5, "Which company owns GitHub?", "Google", "Microsoft", "Apple", "Amazon", 2, "medium", "adults", "Microsoft acquired GitHub in 2018"),
            (5, "What is the purpose of a compiler?", "Run programs", "Translate code", "Design websites", "Manage memory", 2, "hard", "adults", "Compilers translate code to machine language"),
            (5, "Which protocol is used for email?", "HTTP", "FTP", "SMTP", "TCP", 3, "medium", "adults", "SMTP: Simple Mail Transfer Protocol"),
            (5, "What does VR stand for?", "Virtual Reality", "Visual Response", "Video Recording", "Virtual Response", 1, "easy", "adults", "VR: Virtual Reality"),

            # Category 6: History (Adults) - 30 questions
            (6, "In which year did World War II end?", "1944", "1945", "1946", "1947", 2, "easy", "adults", "World War II ended in 1945"),
            (6, "Who was the first president of the United States?", "Thomas Jefferson", "George Washington", "Abraham Lincoln", "John Adams", 2, "easy", "adults", "George Washington was the first president"),
            (6, "Which ancient civilization built the pyramids?", "Romans", "Greeks", "Egyptians", "Mayans", 3, "easy", "adults", "Ancient Egyptians built the pyramids"),
            (6, "When did the Berlin Wall fall?", "1987", "1988", "1989", "1990", 3, "medium", "adults", "Berlin Wall fell in November 1989"),
            (6, "Who discovered America in 1492?", "Christopher Columbus", "Vasco da Gama", "Marco Polo", "James Cook", 1, "easy", "adults", "Christopher Columbus discovered America"),
            (6, "Which empire was ruled by Julius Caesar?", "Roman Empire", "Greek Empire", "Ottoman Empire", "British Empire", 1, "medium", "adults", "Julius Caesar ruled Roman Empire"),
            (6, "When was the Declaration of Independence signed?", "1774", "1775", "1776", "1777", 3, "medium", "adults", "Signed in 1776"),
            (6, "Who was the first woman to win a Nobel Prize?", "Marie Curie", "Rosalind Franklin", "Jane Addams", "Mother Teresa", 1, "medium", "adults", "Marie Curie won in 1903"),
            (6, "Which war was fought between North and South Korea?", "Vietnam War", "Korean War", "Cold War", "World War I", 2, "medium", "adults", "Korean War 1950-1953"),
            (6, "Who painted the Mona Lisa?", "Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo", 3, "easy", "adults", "Leonardo da Vinci painted Mona Lisa"),
            (6, "When did the French Revolution begin?", "1776", "1789", "1799", "1812", 2, "hard", "adults", "French Revolution began in 1789"),
            (6, "Which civilization invented paper?", "Chinese", "Egyptians", "Romans", "Greeks", 1, "medium", "adults", "Ancient Chinese invented paper"),
            (6, "Who was the first man on the moon?", "Buzz Aldrin", "Neil Armstrong", "Yuri Gagarin", "John Glenn", 2, "easy", "adults", "Neil Armstrong in 1969"),
            (6, "When was the United Nations founded?", "1944", "1945", "1946", "1947", 2, "medium", "adults", "UN founded in 1945 after WWII"),
            (6, "Which empire was the largest in history?", "Roman Empire", "British Empire", "Mongol Empire", "Russian Empire", 2, "hard", "adults", "British Empire was the largest"),
            (6, "Who wrote 'The Communist Manifesto'?", "Karl Marx", "Vladimir Lenin", "Joseph Stalin", "Friedrich Engels", 1, "medium", "adults", "Karl Marx co-authored it with Engels"),
            (6, "When did the Cold War end?", "1985", "1989", "1991", "1993", 3, "hard", "adults", "Cold War ended in 1991 with USSR collapse"),
            (6, "Which country was not part of Axis powers in WWII?", "Germany", "Italy", "Japan", "Russia", 4, "medium", "adults", "Russia was part of Allies"),
            (6, "Who was the first female prime minister of UK?", "Theresa May", "Margaret Thatcher", "Angela Merkel", "Indira Gandhi", 2, "medium", "adults", "Margaret Thatcher 1979-1990"),
            (6, "When did India gain independence?", "1945", "1947", "1949", "1950", 2, "medium", "adults", "India gained independence in 1947"),
            (6, "Who was the ancient Greek god of the sky?", "Zeus", "Poseidon", "Hades", "Apollo", 1, "easy", "adults", "Zeus was the king of gods"),
            (6, "Which dynasty built the Great Wall of China?", "Ming", "Qin", "Han", "Tang", 2, "medium", "adults", "Qin dynasty started the Great Wall"),
            (6, "When did the Titanic sink?", "1910", "1912", "1914", "1916", 2, "medium", "adults", "Titanic sank in April 1912"),
            (6, "Who was the first Roman emperor?", "Julius Caesar", "Augustus", "Nero", "Caligula", 2, "hard", "adults", "Augustus was first Roman emperor"),
            (6, "Which war was known as the 'Great War'?", "World War I", "World War II", "Vietnam War", "Korean War", 1, "easy", "adults", "WWI was called the Great War"),
            (6, "Who invented the telephone?", "Thomas Edison", "Alexander Graham Bell", "Nikola Tesla", "Guglielmo Marconi", 2, "easy", "adults", "Alexander Graham Bell invented telephone"),
            (6, "When did the American Civil War end?", "1863", "1865", "1867", "1869", 2, "medium", "adults", "Civil War ended in 1865"),
            (6, "Which pharaoh's tomb was discovered in 1922?", "Cleopatra", "Tutankhamun", "Ramses II", "Khufu", 2, "medium", "adults", "King Tut's tomb discovered in 1922"),
            (6, "Who was the leader of Soviet Union during WWII?", "Lenin", "Stalin", "Khrushchev", "Brezhnev", 2, "medium", "adults", "Stalin led USSR during WWII"),
            (6, "When did the Renaissance period begin?", "1300s", "1400s", "1500s", "1600s", 1, "hard", "adults", "Renaissance began in 14th century"),

            # Category 7: Business (Adults) - 30 questions
            (7, "What does IPO stand for?", "International Purchase Order", "Initial Public Offering", "Investment Portfolio Option", "Internal Profit Organization", 2, "easy", "adults", "IPO: Initial Public Offering"),
            (7, "Which company is known for its 'Just Do It' slogan?", "Adidas", "Nike", "Reebok", "Puma", 2, "easy", "adults", "Nike's famous slogan is 'Just Do It'"),
            (7, "What is the world's largest e-commerce company?", "Amazon", "Alibaba", "eBay", "Walmart", 1, "easy", "adults", "Amazon is the largest e-commerce company"),
            (7, "Which economist wrote 'The Wealth of Nations'?", "John Maynard Keynes", "Adam Smith", "Karl Marx", "Milton Friedman", 2, "medium", "adults", "Adam Smith in 1776"),
            (7, "What does ROI stand for?", "Return on Investment", "Rate of Interest", "Return of Income", "Risk of Investment", 1, "medium", "adults", "ROI: Return on Investment"),
            (7, "Which company created the iPhone?", "Samsung", "Google", "Apple", "Microsoft", 3, "easy", "adults", "Apple created the iPhone"),
            (7, "What is the currency of Japan?", "Yuan", "Won", "Yen", "Ringgit", 3, "easy", "adults", "Japan uses Yen"),
            (7, "Which company owns WhatsApp?", "Google", "Facebook", "Microsoft", "Twitter", 2, "easy", "adults", "Facebook (Meta) owns WhatsApp"),
            (7, "What does GDP stand for?", "Gross Domestic Product", "General Domestic Production", "Gross Development Product", "General Development Production", 1, "medium", "adults", "GDP: Gross Domestic Product"),
            (7, "Which country has the largest economy?", "China", "United States", "Japan", "Germany", 2, "medium", "adults", "USA has the largest economy"),
            (7, "What is inflation?", "Increase in money supply", "Decrease in prices", "Increase in prices", "Economic growth", 3, "medium", "adults", "Inflation is general price increase"),
            (7, "Which company is known for its search engine?", "Amazon", "Google", "Facebook", "Apple", 2, "easy", "adults", "Google is the search engine giant"),
            (7, "What is a bear market?", "Rising stock prices", "Falling stock prices", "Stable market", "New market", 2, "medium", "adults", "Bear market has falling prices"),
            (7, "Which company created Windows operating system?", "Apple", "Microsoft", "IBM", "Google", 2, "easy", "adults", "Microsoft created Windows"),
            (7, "What is the primary purpose of marketing?", "Sell products", "Create awareness", "Build relationships", "All of the above", 4, "medium", "adults", "Marketing encompasses all these"),
            (7, "Which business magnate founded Tesla?", "Bill Gates", "Jeff Bezos", "Mark Zuckerberg", "Elon Musk", 4, "easy", "adults", "Elon Musk leads Tesla"),
            (7, "What does B2B stand for?", "Business to Business", "Buyer to Buyer", "Bank to Bank", "Business to Buyer", 1, "medium", "adults", "B2B: Business to Business"),
            (7, "Which company is the world's largest retailer?", "Amazon", "Walmart", "Target", "Alibaba", 2, "hard", "adults", "Walmart is the largest retailer by revenue"),
            (7, "What is a startup?", "Small business", "New business venture", "Tech company", "All of the above", 2, "easy", "adults", "Startup is a new business venture"),
            (7, "Which currency is used in the United Kingdom?", "Euro", "Dollar", "Pound", "Franc", 3, "easy", "adults", "UK uses Pound Sterling"),
            (7, "What does CRM stand for?", "Customer Relationship Management", "Company Resource Management", "Customer Revenue Management", "Company Relationship Management", 1, "medium", "adults", "CRM: Customer Relationship Management"),
            (7, "Which company owns Instagram?", "Google", "Facebook", "Twitter", "Microsoft", 2, "easy", "adults", "Facebook (Meta) owns Instagram"),
            (7, "What is the Dow Jones?", "Bank", "Stock market index", "Company", "Currency", 2, "medium", "adults", "Dow Jones is a stock market index"),
            (7, "Which country is the largest exporter of oil?", "USA", "Russia", "Saudi Arabia", "China", 3, "medium", "adults", "Saudi Arabia is largest oil exporter"),
            (7, "What is venture capital?", "Government funding", "Investment in startups", "Bank loans", "Stock trading", 2, "medium", "adults", "Venture capital funds startups"),
            (7, "Which company created the PlayStation?", "Microsoft", "Nintendo", "Sony", "Sega", 3, "easy", "adults", "Sony created PlayStation"),
            (7, "What is blockchain technology used for?", "Gaming", "Cryptocurrency", "Social media", "All of the above", 2, "medium", "adults", "Blockchain is basis for cryptocurrency"),
            (7, "Which company is known for 'Think Different' slogan?", "Apple", "Microsoft", "IBM", "Dell", 1, "medium", "adults", "Apple's famous slogan"),
            (7, "What is the S&P 500?", "Company", "Stock index", "Bank", "Law", 2, "hard", "adults", "S&P 500 is US stock market index"),
            (7, "Which country has the highest GDP per capita?", "USA", "Switzerland", "Qatar", "Luxembourg", 4, "hard", "adults", "Luxembourg has highest GDP per capita"),

            # Category 8: Current Affairs (Adults) - 30 questions
            (8, "Who is the current CEO of Microsoft?", "Bill Gates", "Steve Ballmer", "Satya Nadella", "Tim Cook", 3, "easy", "adults", "Satya Nadella became CEO in 2014"),
            (8, "Which country hosted the 2022 FIFA World Cup?", "USA", "Qatar", "Russia", "Brazil", 2, "easy", "adults", "Qatar hosted 2022 World Cup"),
            (8, "What is the capital of Australia?", "Sydney", "Melbourne", "Canberra", "Perth", 3, "medium", "adults", "Canberra is the capital"),
            (8, "Which company developed ChatGPT?", "Google", "Microsoft", "OpenAI", "Facebook", 3, "easy", "adults", "OpenAI developed ChatGPT"),
            (8, "Who is the current Secretary-General of UN?", "Ban Ki-moon", "Antonio Guterres", "Kofi Annan", "Boutros Boutros-Ghali", 2, "medium", "adults", "Antonio Guterres since 2017"),
            (8, "Which country recently launched a lunar mission?", "India", "China", "USA", "Russia", 1, "medium", "adults", "India's Chandrayaan-3 in 2023"),
            (8, "What is the currency of Sweden?", "Euro", "Krona", "Pound", "Franc", 2, "medium", "adults", "Sweden uses Krona"),
            (8, "Which tech giant recently laid off thousands of employees?", "Google", "Microsoft", "Meta", "All of the above", 4, "medium", "adults", "All major tech companies had layoffs"),
            (8, "Who won the 2023 Nobel Peace Prize?", "Malala Yousafzai", "Narges Mohammadi", "Greta Thunberg", "WHO", 2, "hard", "adults", "Narges Mohammadi in 2023"),
            (8, "Which country has the largest population?", "India", "China", "USA", "Indonesia", 1, "medium", "adults", "India recently surpassed China"),
            (8, "What is the main issue discussed at COP meetings?", "Trade", "Climate Change", "Health", "Education", 2, "easy", "adults", "COP discusses climate change"),
            (8, "Which social media platform was rebranded to X?", "Facebook", "Twitter", "Instagram", "TikTok", 2, "easy", "adults", "Twitter rebranded to X in 2023"),
            (8, "Who is the current President of Russia?", "Vladimir Putin", "Dmitry Medvedev", "Boris Yeltsin", "Mikhail Gorbachev", 1, "easy", "adults", "Vladimir Putin is current president"),
            (8, "Which disease was declared a pandemic in 2020?", "Ebola", "COVID-19", "Swine Flu", "SARS", 2, "easy", "adults", "COVID-19 pandemic started in 2020"),
            (8, "What is the European Union's currency?", "Dollar", "Pound", "Euro", "Franc", 3, "easy", "adults", "Euro is EU's currency"),
            (8, "Which country recently joined NATO?", "Sweden", "Finland", "Ukraine", "Both 1 and 2", 4, "medium", "adults", "Sweden and Finland joined NATO"),
            (8, "Who is the CEO of Tesla?", "Jeff Bezos", "Tim Cook", "Elon Musk", "Mark Zuckerberg", 3, "easy", "adults", "Elon Musk is Tesla CEO"),
            (8, "Which country has the most Olympic medals?", "USA", "China", "Russia", "Germany", 1, "medium", "adults", "USA has the most Olympic medals"),
            (8, "What is the main function of the World Bank?", "Military support", "Economic development", "Health care", "Education", 2, "medium", "adults", "World Bank focuses on economic development"),
            (8, "Which company recently launched Threads app?", "Twitter", "Meta", "Google", "Microsoft", 2, "easy", "adults", "Meta launched Threads in 2023"),
            (8, "Who is the current UK Prime Minister?", "Boris Johnson", "Rishi Sunak", "Liz Truss", "Theresa May", 2, "medium", "adults", "Rishi Sunak became PM in 2022"),
            (8, "Which country won the 2022 FIFA World Cup?", "France", "Argentina", "Brazil", "Germany", 2, "easy", "adults", "Argentina won in 2022"),
            (8, "What is ChatGPT primarily used for?", "Image editing", "Conversational AI", "Video games", "Social media", 2, "easy", "adults", "ChatGPT is conversational AI"),
            (8, "Which country recently changed its name?", "Turkey", "India", "China", "Russia", 1, "medium", "adults", "Turkey changed to Türkiye"),
            (8, "Who is the richest person in the world?", "Jeff Bezos", "Elon Musk", "Bernard Arnault", "Bill Gates", 2, "medium", "adults", "Elon Musk is often richest"),
            (8, "Which company developed the COVID-19 vaccine first?", "Pfizer", "Moderna", "AstraZeneca", "Johnson & Johnson", 1, "medium", "adults", "Pfizer developed first approved vaccine"),
            (8, "What is the current global population?", "6 billion", "7 billion", "8 billion", "9 billion", 3, "medium", "adults", "World population reached 8 billion"),
            (8, "Which country has the most powerful military?", "USA", "Russia", "China", "India", 1, "hard", "adults", "USA has most powerful military"),
            (8, "Who won the 2023 US Open tennis men's singles?", "Novak Djokovic", "Carlos Alcaraz", "Rafael Nadal", "Daniil Medvedev", 2, "hard", "adults", "Carlos Alcaraz won in 2023"),
            (8, "Which city will host the 2024 Summer Olympics?", "Paris", "Los Angeles", "Tokyo", "London", 1, "medium", "adults", "Paris hosts 2024 Olympics"),
        ]

    def get_categories_by_age_group(self, age_group):
        """Get categories for specific age group"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM categories WHERE age_group = ?", (age_group,))
        categories = cursor.fetchall()
        conn.close()
        
        print(f"📋 Found {len(categories)} categories for {age_group}:")
        for cat in categories:
            print(f"   - {cat[1]} (ID: {cat[0]})")
            
        return categories

    def get_questions_by_category(self, category_id, difficulty=None, limit=10):
        """Get questions by category with optional difficulty filter"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        query = "SELECT * FROM questions WHERE category_id = ?"
        params = [category_id]
        
        if difficulty:
            query += " AND difficulty = ?"
            params.append(difficulty)
        
        query += " ORDER BY RANDOM() LIMIT ?"
        params.append(limit)
        
        cursor.execute(query, params)
        questions = cursor.fetchall()
        conn.close()
        
        print(f"❓ Found {len(questions)} questions for category ID {category_id}")
        return questions

    def get_question_count_by_category(self, category_id):
        """Get total number of questions in a category"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM questions WHERE category_id = ?", (category_id,))
        count = cursor.fetchone()[0]
        conn.close()
        return count
