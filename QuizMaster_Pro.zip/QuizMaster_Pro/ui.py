import tkinter as tk
from tkinter import ttk, messagebox
import os
from quiz_logic import QuizManager, UserManager, AchievementManager
from database import DatabaseManager
from config import *

class QuizApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} 🎯")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.configure(bg=BG_COLOR)
        
        # Center the window
        self.center_window()
        
        # Initialize managers
        self.db = DatabaseManager()
        self.user_manager = UserManager()
        self.quiz_manager = QuizManager()
        self.achievement_manager = AchievementManager()
        
        # Create main container
        self.main_frame = tk.Frame(self.root, bg=BG_COLOR)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Show login screen initially
        self.show_login_screen()
    
    def center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def clear_screen(self):
        """Clear all widgets from main frame"""
        for widget in self.main_frame.winfo_children():
            widget.destroy()
    
    def create_modern_button(self, parent, text, command, **kwargs):
        """Create a modern styled button"""
        bg_color = kwargs.get('bg_color', COLORS["primary"])
        fg_color = kwargs.get('fg_color', "white")
        width = kwargs.get('width', 20)
        font_size = kwargs.get('font_size', 12)
        
        button = tk.Button(parent,
                          text=text,
                          command=command,
                          bg=bg_color,
                          fg=fg_color,
                          font=('Arial', font_size, 'bold'),
                          width=width,
                          height=2,
                          relief='flat',
                          borderwidth=0,
                          cursor='hand2')
        return button
    
    def show_login_screen(self):
        """Show login/registration screen"""
        self.clear_screen()
        
        # Header
        header_frame = tk.Frame(self.main_frame, bg=BG_COLOR)
        header_frame.pack(pady=50)
        
        tk.Label(header_frame, 
                text="🎯 QuizMaster Pro", 
                font=('Arial', 32, 'bold'), 
                bg=BG_COLOR, 
                fg='white').pack()
        
        tk.Label(header_frame, 
                text="Learn • Play • Achieve", 
                font=('Arial', 14), 
                bg=BG_COLOR, 
                fg=COLORS["light"]).pack(pady=10)
        
        # Login Card
        login_card = tk.Frame(self.main_frame, bg='white', relief='raised', borderwidth=2)
        login_card.pack(pady=20, padx=100, fill='x')
        
        # Card content
        card_content = tk.Frame(login_card, bg='white')
        card_content.pack(padx=40, pady=40)
        
        # Title
        tk.Label(card_content, 
                text="Welcome!", 
                font=('Arial', 20, 'bold'), 
                bg='white', 
                fg=COLORS["primary"]).pack(pady=(0, 20))
        
        # Username
        tk.Label(card_content, text="Username:", 
                font=('Arial', 12, 'bold'), 
                bg='white', fg=COLORS["dark"]).pack(anchor='w', pady=(10, 5))
        
        self.username_entry = tk.Entry(card_content, 
                                      font=('Arial', 12), 
                                      bg=COLORS["light"], 
                                      relief='flat', 
                                      width=30)
        self.username_entry.pack(fill='x', pady=(0, 15))
        
        # Password
        tk.Label(card_content, text="Password:", 
                font=('Arial', 12, 'bold'), 
                bg='white', fg=COLORS["dark"]).pack(anchor='w', pady=(5, 5))
        
        self.password_entry = tk.Entry(card_content, 
                                      font=('Arial', 12), 
                                      bg=COLORS["light"], 
                                      relief='flat', 
                                      show="•", 
                                      width=30)
        self.password_entry.pack(fill='x', pady=(0, 20))
        
        # Age group selection
        age_frame = tk.Frame(card_content, bg='white')
        age_frame.pack(fill='x', pady=10)
        
        self.age_var = tk.StringVar(value=AGE_GROUP_ADULTS)
        
        tk.Label(age_frame, text="Select Mode:", 
                font=('Arial', 12, 'bold'), 
                bg='white', fg=COLORS["dark"]).pack(anchor='w')
        
        age_radio_frame = tk.Frame(age_frame, bg='white')
        age_radio_frame.pack(fill='x', pady=5)
        
        tk.Radiobutton(age_radio_frame, 
                      text="🧒 Kids Mode (8-12)", 
                      variable=self.age_var, 
                      value=AGE_GROUP_KIDS,
                      font=('Arial', 11), 
                      bg='white', 
                      fg=COLORS["dark"]).pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Radiobutton(age_radio_frame, 
                      text="👨‍💼 Adult Mode (13+)", 
                      variable=self.age_var, 
                      value=AGE_GROUP_ADULTS,
                      font=('Arial', 11), 
                      bg='white', 
                      fg=COLORS["dark"]).pack(side=tk.LEFT)
        
        # Buttons
        button_frame = tk.Frame(card_content, bg='white')
        button_frame.pack(fill='x', pady=20)
        
        # Login button
        login_btn = self.create_modern_button(button_frame, 
                                            "🚀 Login", 
                                            lambda: self.handle_login(
                                                self.username_entry.get(), 
                                                self.password_entry.get()),
                                            bg_color=COLORS["primary"],
                                            font_size=14)
        login_btn.pack(pady=5)
        
        # Register button
        register_btn = self.create_modern_button(button_frame, 
                                               "⭐ Create Account", 
                                               lambda: self.handle_register(
                                                   self.username_entry.get(), 
                                                   self.password_entry.get()),
                                               bg_color=COLORS["success"],
                                               font_size=14)
        register_btn.pack(pady=5)
        
        # Test accounts info
        info_frame = tk.Frame(card_content, bg='white')
        info_frame.pack(fill='x', pady=10)
        
        tk.Label(info_frame, 
                text="💡 Test Accounts: kid_user/1234 (Kids) • adult_user/1234 (Adults)", 
                font=('Arial', 10), 
                bg='white', 
                fg=COLORS["dark"]).pack()
        
        # Bind Enter key to login
        self.password_entry.bind('<Return>', lambda e: self.handle_login(
            self.username_entry.get(), self.password_entry.get()))
        
        # Focus on username field
        self.username_entry.focus()
    
    def handle_login(self, username, password):
        """Handle user login"""
        if not username or not password:
            messagebox.showerror("Error", "❌ Please enter both username and password")
            return
        
        success, message = self.user_manager.login_user(username, password)
        if success:
            messagebox.showinfo("Welcome", f"🎉 Welcome back, {username}!")
            self.show_age_selection()
        else:
            messagebox.showerror("Login Failed", f"❌ {message}")
    
    def handle_register(self, username, password):
        """Handle user registration"""
        if not username or not password:
            messagebox.showerror("Error", "❌ Please enter both username and password")
            return
        
        if len(username) < 3:
            messagebox.showerror("Error", "❌ Username must be at least 3 characters long")
            return
        
        if len(password) < 4:
            messagebox.showerror("Error", "❌ Password must be at least 4 characters long")
            return
        
        success, message = self.user_manager.register_user(username, password, self.age_var.get())
        if success:
            messagebox.showinfo("Success", f"✅ {message}")
            self.show_age_selection()
        else:
            messagebox.showerror("Registration Failed", f"❌ {message}")
    
    def show_age_selection(self):
        """Show age group selection screen"""
        self.clear_screen()
        
        # Header
        header_frame = tk.Frame(self.main_frame, bg=BG_COLOR)
        header_frame.pack(pady=30)
        
        tk.Label(header_frame, 
                text="Choose Your Adventure 🎮", 
                font=('Arial', 28, 'bold'), 
                bg=BG_COLOR, 
                fg='white').pack(pady=10)
        
        tk.Label(header_frame, 
                text="Select the perfect learning experience for you", 
                font=('Arial', 14), 
                bg=BG_COLOR, 
                fg=COLORS["light"]).pack()
        
        # Cards container
        cards_frame = tk.Frame(self.main_frame, bg=BG_COLOR)
        cards_frame.pack(expand=True, pady=40)
        
        # Kids card
        kids_frame = tk.Frame(cards_frame, bg='#FF6B6B', relief='raised', borderwidth=2)
        kids_frame.pack(side=tk.LEFT, padx=20, fill='both', expand=True)
        
        kids_content = tk.Frame(kids_frame, bg='#FF6B6B')
        kids_content.pack(padx=30, pady=30)
        
        tk.Label(kids_content, text="🧒", font=('Arial', 48), 
                bg='#FF6B6B', fg='white').pack(pady=10)
        tk.Label(kids_content, text="KIDS MODE", font=('Arial', 20, 'bold'), 
                bg='#FF6B6B', fg='white').pack()
        tk.Label(kids_content, text="Ages 8-12", font=('Arial', 14), 
                bg='#FF6B6B', fg='white').pack(pady=5)
        tk.Label(kids_content, text="• Fun & Educational\n• Colorful Interface\n• Easy Questions", 
                font=('Arial', 12), bg='#FF6B6B', fg='white', justify=tk.LEFT).pack(pady=15)
        
        kids_btn = self.create_modern_button(kids_content, "Start Learning 🎨", 
                                           lambda: self.show_category_selection(AGE_GROUP_KIDS),
                                           bg_color='white', fg_color='#FF6B6B',
                                           font_size=14)
        kids_btn.pack(pady=20)
        
        # Adults card
        adults_frame = tk.Frame(cards_frame, bg='#4ECDC4', relief='raised', borderwidth=2)
        adults_frame.pack(side=tk.LEFT, padx=20, fill='both', expand=True)
        
        adults_content = tk.Frame(adults_frame, bg='#4ECDC4')
        adults_content.pack(padx=30, pady=30)
        
        tk.Label(adults_content, text="👨‍💼", font=('Arial', 48), 
                bg='#4ECDC4', fg='white').pack(pady=10)
        tk.Label(adults_content, text="ADULT MODE", font=('Arial', 20, 'bold'), 
                bg='#4ECDC4', fg='white').pack()
        tk.Label(adults_content, text="Age 13+", font=('Arial', 14), 
                bg='#4ECDC4', fg='white').pack(pady=5)
        tk.Label(adults_content, text="• Challenging Questions\n• Professional Topics\n• Current Affairs", 
                font=('Arial', 12), bg='#4ECDC4', fg='white', justify=tk.LEFT).pack(pady=15)
        
        adults_btn = self.create_modern_button(adults_content, "Start Quiz 🚀", 
                                             lambda: self.show_category_selection(AGE_GROUP_ADULTS),
                                             bg_color='white', fg_color='#4ECDC4',
                                             font_size=14)
        adults_btn.pack(pady=20)
        
        # Navigation
        nav_frame = tk.Frame(self.main_frame, bg=BG_COLOR)
        nav_frame.pack(pady=20)
        
        self.create_modern_button(nav_frame, "👤 My Profile", self.show_profile,
                                bg_color=COLORS["success"], font_size=11, width=15).pack(side=tk.LEFT, padx=5)
        
        self.create_modern_button(nav_frame, "🏆 Achievements", self.show_achievements,
                                bg_color=COLORS["warning"], font_size=11, width=15).pack(side=tk.LEFT, padx=5)
        
        self.create_modern_button(nav_frame, "🚪 Logout", self.show_login_screen,
                                bg_color=COLORS["danger"], font_size=11, width=15).pack(side=tk.LEFT, padx=5)
    
    def show_category_selection(self, age_group):
        """Show category selection screen"""
        self.clear_screen()
        
        # Header
        header_frame = tk.Frame(self.main_frame, bg=BG_COLOR)
        header_frame.pack(pady=20)
        
        mode_text = "🧒 Kids Learning" if age_group == AGE_GROUP_KIDS else "👨‍💼 Adult Challenges"
        tk.Label(header_frame, 
                text=f"Choose Your Category - {mode_text}", 
                font=('Arial', 24, 'bold'), 
                bg=BG_COLOR, 
                fg='white').pack(pady=10)
        
        # Get categories
        categories = self.db.get_categories_by_age_group(age_group)
        
        # Categories grid
        categories_frame = tk.Frame(self.main_frame, bg=BG_COLOR)
        categories_frame.pack(expand=True, fill='both', pady=20)
        
        # Create category cards in 2x2 grid
        row, col = 0, 0
        for category in categories:
            cat_id, name, description, age_grp, icon_path = category
            
            # Category card
            card_color = self.get_category_color(cat_id)
            category_frame = tk.Frame(categories_frame, bg=card_color, relief='raised', borderwidth=2)
            category_frame.grid(row=row, column=col, padx=15, pady=15, sticky='nsew')
            
            # Card content
            content_frame = tk.Frame(category_frame, bg=card_color)
            content_frame.pack(expand=True, fill='both', padx=20, pady=20)
            
            # Emoji icon
            emoji = self.get_category_emoji(name)
            tk.Label(content_frame, text=emoji, font=('Arial', 36), 
                    bg=card_color, fg='white').pack(pady=10)
            
            # Category name
            tk.Label(content_frame, text=name, font=('Arial', 16, 'bold'), 
                    bg=card_color, fg='white').pack()
            
            # Description
            tk.Label(content_frame, text=description, font=('Arial', 10), 
                    bg=card_color, fg='white', wraplength=200).pack(pady=5)
            
            # Start button
            start_btn = self.create_modern_button(content_frame, "Start Quiz 🚀", 
                                                lambda cid=cat_id: self.start_quiz(cid),
                                                bg_color='white', 
                                                fg_color=card_color,
                                                font_size=11,
                                                width=15)
            start_btn.pack(pady=15)
            
            col += 1
            if col > 1:
                col = 0
                row += 1
        
        # Configure grid weights
        for i in range(2):
            categories_frame.columnconfigure(i, weight=1)
        for i in range(row + 1):
            categories_frame.rowconfigure(i, weight=1)
        
        # Navigation
        nav_frame = tk.Frame(self.main_frame, bg=BG_COLOR)
        nav_frame.pack(pady=20)
        
        self.create_modern_button(nav_frame, "⬅️ Back", self.show_age_selection,
                                bg_color=COLORS["warning"], font_size=11, width=12).pack(side=tk.LEFT, padx=5)
        
        self.create_modern_button(nav_frame, "👤 Profile", self.show_profile,
                                bg_color=COLORS["success"], font_size=11, width=12).pack(side=tk.LEFT, padx=5)
        
        self.create_modern_button(nav_frame, "🏆 Achievements", self.show_achievements,
                                bg_color=COLORS["primary"], font_size=11, width=12).pack(side=tk.LEFT, padx=5)
    
    def get_category_color(self, category_id):
        """Get unique color for each category"""
        colors = [
            "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4",  # Kids categories
            "#FECA57", "#FF9FF3", "#54A0FF", "#5F27CD"   # Adult categories
        ]
        return colors[category_id - 1] if category_id <= len(colors) else COLORS["primary"]
    
    def get_category_emoji(self, category_name):
        """Get emoji for category"""
        emojis = {
            "Animals": "🐾",
            "Cartoons": "📺",
            "Science Fun": "🔬",
            "General Knowledge": "🌟",
            "Technology": "💻",
            "History": "🏛️",
            "Business": "💼",
            "Current Affairs": "📰"
        }
        return emojis.get(category_name, "📚")
    
    def start_quiz(self, category_id):
        """Start a new quiz"""
        self.clear_screen()
        
        questions_count = self.quiz_manager.start_new_quiz(
            self.user_manager.current_user[0], category_id
        )
        
        if questions_count == 0:
            messagebox.showerror("Error", "❌ No questions available for this category!")
            self.show_category_selection(self.user_manager.current_user[3])
            return
        
        self.show_question()
    
    def show_question(self):
        """Display question interface"""
        self.clear_screen()
        
        question_data = self.quiz_manager.get_current_question()
        if not question_data:
            self.finish_quiz()
            return
        
        # Header with progress
        header_frame = tk.Frame(self.main_frame, bg=COLORS["primary"])
        header_frame.pack(fill='x', pady=(0, 20))
        
        header_content = tk.Frame(header_frame, bg=COLORS["primary"])
        header_content.pack(fill='x', padx=30, pady=20)
        
        # Progress info
        progress_top = tk.Frame(header_content, bg=COLORS["primary"])
        progress_top.pack(fill='x')
        
        progress = self.quiz_manager.get_quiz_progress()
        question_num = self.quiz_manager.get_question_number() + 1
        total_questions = self.quiz_manager.total_questions
        
        tk.Label(progress_top, 
                text=f"Question {question_num} of {total_questions}", 
                font=('Arial', 14, 'bold'), 
                bg=COLORS["primary"], 
                fg='white').pack(side=tk.LEFT)
        
        # Score and streak
        stats_frame = tk.Frame(progress_top, bg=COLORS["primary"])
        stats_frame.pack(side=tk.RIGHT)
        
        tk.Label(stats_frame, text=f"🏆 Score: {self.quiz_manager.score}", 
                font=('Arial', 12, 'bold'), bg=COLORS["primary"], fg='white').pack(side=tk.LEFT, padx=10)
        
        if self.quiz_manager.current_streak > 1:
            tk.Label(stats_frame, text=f"🔥 Streak: {self.quiz_manager.current_streak}", 
                    font=('Arial', 12, 'bold'), bg=COLORS["primary"], fg=COLORS["warning"]).pack(side=tk.LEFT, padx=10)
        
        # Progress bar
        progress_frame = tk.Frame(header_content, bg=COLORS["primary"])
        progress_frame.pack(fill='x', pady=(15, 0))
        
        progress_bar = ttk.Progressbar(progress_frame, 
                                     orient=tk.HORIZONTAL, 
                                     length=600, 
                                     mode='determinate')
        progress_bar['value'] = progress
        progress_bar.pack(fill='x')
        
        # Question card
        question_frame = tk.Frame(self.main_frame, bg='white', relief='raised', borderwidth=2)
        question_frame.pack(expand=True, fill='both', pady=10)
        
        question_content = tk.Frame(question_frame, bg='white')
        question_content.pack(expand=True, fill='both', padx=40, pady=40)
        
        # Question text
        tk.Label(question_content, 
                text=question_data['question_text'], 
                font=('Arial', 18, 'bold'), 
                bg='white', 
                fg=COLORS["dark"],
                wraplength=700,
                justify=tk.CENTER).pack(pady=30)
        
        # Options frame
        options_frame = tk.Frame(question_content, bg='white')
        options_frame.pack(expand=True, fill='both', pady=20)
        
        self.option_var = tk.IntVar()
        
        # Create option buttons
        for i, option in enumerate(question_data['options'], 1):
            option_frame = tk.Frame(options_frame, bg='#f0f0f0', relief='raised', borderwidth=1)
            option_frame.pack(fill='x', pady=8, padx=20)
            
            option_btn = tk.Radiobutton(option_frame, 
                                      text=option,
                                      variable=self.option_var,
                                      value=i,
                                      font=('Arial', 14),
                                      bg='#f0f0f0',
                                      fg=COLORS["dark"],
                                      wraplength=600,
                                      justify=tk.LEFT)
            option_btn.pack(anchor='w', pady=12, padx=20)
        
        # Action buttons
        action_frame = tk.Frame(question_content, bg='white')
        action_frame.pack(fill='x', pady=30)
        
        self.create_modern_button(action_frame, "✅ Submit Answer", self.submit_answer,
                                bg_color=COLORS["success"], font_size=14, width=18).pack(side=tk.LEFT, padx=10)
        
        self.create_modern_button(action_frame, "⏭️ Skip Question", self.skip_question,
                                bg_color=COLORS["warning"], font_size=14, width=18).pack(side=tk.LEFT, padx=10)
        
        self.create_modern_button(action_frame, "🚪 Quit Quiz", 
                                lambda: self.show_category_selection(self.user_manager.current_user[3]),
                                bg_color=COLORS["danger"], font_size=14, width=18).pack(side=tk.LEFT, padx=10)
        
        # Auto-select first option
        if question_data['options']:
            self.option_var.set(1)
    
    def submit_answer(self):
        """Submit the selected answer"""
        if self.option_var.get() == 0:
            messagebox.showwarning("Warning", "⚠️ Please select an answer!")
            return
        
        result = self.quiz_manager.submit_answer(self.option_var.get())
        self.show_answer_feedback(result)
    
    def skip_question(self):
        """Skip the current question"""
        self.quiz_manager.skip_question()
        self.show_question()
    
    def show_answer_feedback(self, result):
        """Show answer feedback"""
        self.clear_screen()
        
        # Result card
        result_frame = tk.Frame(self.main_frame, bg='white', relief='raised', borderwidth=2)
        result_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        result_content = tk.Frame(result_frame, bg='white')
        result_content.pack(expand=True, fill='both', padx=40, pady=40)
        
        # Result icon and message
        if result['is_correct']:
            result_color = COLORS["success"]
            result_icon = "🎉"
            result_text = "Correct! Excellent Work!"
        else:
            result_color = COLORS["danger"]
            result_icon = "💡"
            result_text = "Not Quite Right"
        
        # Result header
        result_header = tk.Frame(result_content, bg='white')
        result_header.pack(pady=20)
        
        tk.Label(result_header, text=result_icon, font=('Arial', 48), 
                bg='white').pack()
        tk.Label(result_header, text=result_text, font=('Arial', 24, 'bold'), 
                bg='white', fg=result_color).pack(pady=10)
        
        # Explanation
        if result['explanation']:
            expl_frame = tk.Frame(result_content, bg=COLORS["light"], relief='raised', borderwidth=1)
            expl_frame.pack(fill='x', pady=20, padx=50)
            
            expl_content = tk.Frame(expl_frame, bg=COLORS["light"])
            expl_content.pack(padx=25, pady=20)
            
            tk.Label(expl_content, text="💡 Explanation:", 
                    font=('Arial', 16, 'bold'), bg=COLORS["light"], fg=COLORS["dark"]).pack(anchor='w')
            tk.Label(expl_content, text=result['explanation'], 
                    font=('Arial', 14), bg=COLORS["light"], fg=COLORS["dark"],
                    wraplength=600, justify=tk.LEFT).pack(anchor='w', pady=10)
        
        # Stats
        stats_frame = tk.Frame(result_content, bg=COLORS["primary"], relief='raised', borderwidth=1)
        stats_frame.pack(fill='x', pady=20, padx=50)
        
        stats_content = tk.Frame(stats_frame, bg=COLORS["primary"])
        stats_content.pack(padx=25, pady=15)
        
        tk.Label(stats_content, text=f"🏆 Current Score: {result['current_score']}", 
                font=('Arial', 18, 'bold'), bg=COLORS["primary"], fg='white').pack()
        
        # Continue button
        continue_btn = self.create_modern_button(result_content, "➡️ Next Question", 
                                               self.show_question,
                                               bg_color=COLORS["primary"],
                                               font_size=16, width=20)
        continue_btn.pack(pady=30)
    
    def finish_quiz(self):
        """Show quiz results screen"""
        success, unlocked_achievements = self.quiz_manager.save_quiz_results()
        results = self.quiz_manager.get_quiz_results()
        
        self.clear_screen()
        
        # Results card
        results_frame = tk.Frame(self.main_frame, bg='white', relief='raised', borderwidth=2)
        results_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        results_content = tk.Frame(results_frame, bg='white')
        results_content.pack(expand=True, fill='both', padx=40, pady=40)
        
        # Celebration header
        header_frame = tk.Frame(results_content, bg='white')
        header_frame.pack(pady=20)
        
        tk.Label(header_frame, text="🎊 Quiz Completed! 🎊", 
                font=('Arial', 28, 'bold'), bg='white', fg=COLORS["primary"]).pack()
        
        # Performance message
        if results['accuracy'] >= 90:
            performance_msg = "🏆 Outstanding! You're a quiz master! 🏆"
        elif results['accuracy'] >= 70:
            performance_msg = "👍 Great job! You know your stuff!"
        elif results['accuracy'] >= 50:
            performance_msg = "😊 Good effort! Keep practicing!"
        else:
            performance_msg = "💪 Keep learning! You'll get better!"
        
        tk.Label(header_frame, text=performance_msg, 
                font=('Arial', 16, 'bold'), bg='white', fg=COLORS["primary"]).pack(pady=10)
        
        # Results stats
        stats_frame = tk.Frame(results_content, bg=COLORS["light"], relief='raised', borderwidth=1)
        stats_frame.pack(fill='x', pady=20, padx=50)
        
        stats_content = tk.Frame(stats_frame, bg=COLORS["light"])
        stats_content.pack(padx=30, pady=25)
        
        stats_text = f"""
        📊 Total Questions: {results['total_questions']}
        ✅ Correct Answers: {results['correct_answers']}
        🏆 Final Score: {results['score']} points
        📈 Accuracy: {results['accuracy']:.1f}%
        ⏱️ Time Taken: {results['time_taken']:.1f} seconds
        🔥 Best Streak: {results['max_streak']} in a row
        """
        
        tk.Label(stats_content, text=stats_text, font=('Arial', 16),
                bg=COLORS["light"], fg=COLORS["dark"], justify=tk.LEFT).pack()
        
        # Action buttons
        action_frame = tk.Frame(results_content, bg='white')
        action_frame.pack(fill='x', pady=30)
        
        self.create_modern_button(action_frame, "🔄 Play Again", 
                                lambda: self.show_category_selection(self.user_manager.current_user[3]),
                                bg_color=COLORS["success"], font_size=14, width=15).pack(side=tk.LEFT, padx=10)
        
        self.create_modern_button(action_frame, "🏠 Main Menu", self.show_age_selection,
                                bg_color=COLORS["primary"], font_size=14, width=15).pack(side=tk.LEFT, padx=10)
        
        self.create_modern_button(action_frame, "👤 View Profile", self.show_profile,
                                bg_color=COLORS["warning"], font_size=14, width=15).pack(side=tk.LEFT, padx=10)
    
    def show_profile(self):
        """Show user profile"""
        self.clear_screen()
        
        if not self.user_manager.current_user:
            self.show_login_screen()
            return
        
        user_id = self.user_manager.current_user[0]
        stats = self.user_manager.get_user_stats(user_id)
        username = self.user_manager.current_user[1]
        age_group = self.user_manager.current_user[3]
        
        # Profile card
        profile_frame = tk.Frame(self.main_frame, bg='white', relief='raised', borderwidth=2)
        profile_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        profile_content = tk.Frame(profile_frame, bg='white')
        profile_content.pack(expand=True, fill='both', padx=40, pady=40)
        
        # Header
        header_frame = tk.Frame(profile_content, bg='white')
        header_frame.pack(pady=20)
        
        tk.Label(header_frame, text="👤 User Profile", 
                font=('Arial', 24, 'bold'), bg='white', fg=COLORS["primary"]).pack()
        
        tk.Label(header_frame, text=f"Welcome, {username}!", 
                font=('Arial', 16), bg='white', fg=COLORS["dark"]).pack(pady=5)
        
        # Mode badge
        mode_badge = "🧒 Kids Mode" if age_group == AGE_GROUP_KIDS else "👨‍💼 Adult Mode"
        badge_color = "#FF6B6B" if age_group == AGE_GROUP_KIDS else "#4ECDC4"
        
        badge_frame = tk.Frame(header_frame, bg=badge_color)
        badge_frame.pack(pady=10)
        
        tk.Label(badge_frame, text=mode_badge, font=('Arial', 14, 'bold'),
                bg=badge_color, fg='white', padx=20, pady=5).pack()
        
        # Stats
        stats_frame = tk.Frame(profile_content, bg=COLORS["light"], relief='raised', borderwidth=1)
        stats_frame.pack(fill='x', pady=20, padx=50)
        
        stats_content = tk.Frame(stats_frame, bg=COLORS["light"])
        stats_content.pack(padx=30, pady=25)
        
        stats_text = f"""
        📊 Total Quizzes Completed: {stats['total_quizzes']}
        ❓ Total Questions Answered: {stats['total_questions']}
        🏆 Total Score: {stats['total_score']} points
        📈 Average Accuracy: {stats['average_accuracy']}%
        """
        
        tk.Label(stats_content, text=stats_text, font=('Arial', 16),
                bg=COLORS["light"], fg=COLORS["dark"], justify=tk.LEFT).pack()
        
        # Navigation
        nav_frame = tk.Frame(profile_content, bg='white')
        nav_frame.pack(fill='x', pady=30)
        
        self.create_modern_button(nav_frame, "⬅️ Back to Menu", self.show_age_selection,
                                bg_color=COLORS["primary"], font_size=12, width=15).pack(side=tk.LEFT, padx=5)
        
        self.create_modern_button(nav_frame, "🏆 Achievements", self.show_achievements,
                                bg_color=COLORS["success"], font_size=12, width=15).pack(side=tk.LEFT, padx=5)
        
        self.create_modern_button(nav_frame, "🚪 Logout", self.show_login_screen,
                                bg_color=COLORS["danger"], font_size=12, width=15).pack(side=tk.LEFT, padx=5)
    
    def show_achievements(self):
        """Show achievements screen"""
        self.clear_screen()
        
        if not self.user_manager.current_user:
            self.show_login_screen()
            return
        
        user_id = self.user_manager.current_user[0]
        achievements = self.achievement_manager.get_user_achievements(user_id)
        
        # Achievements card
        achievements_frame = tk.Frame(self.main_frame, bg='white', relief='raised', borderwidth=2)
        achievements_frame.pack(expand=True, fill='both', padx=50, pady=50)
        
        achievements_content = tk.Frame(achievements_frame, bg='white')
        achievements_content.pack(expand=True, fill='both', padx=40, pady=40)
        
        # Header
        header_frame = tk.Frame(achievements_content, bg='white')
        header_frame.pack(pady=20)
        
        tk.Label(header_frame, text="🏆 Your Achievements", 
                font=('Arial', 24, 'bold'), bg='white', fg=COLORS["primary"]).pack()
        
        # Create notebook for unlocked and locked achievements
        notebook = ttk.Notebook(achievements_content)
        notebook.pack(expand=True, fill='both', pady=20)
        
        # Unlocked achievements tab
        unlocked_frame = tk.Frame(notebook, bg='white')
        notebook.add(unlocked_frame, text=f"Unlocked ({len(achievements['unlocked'])})")
        
        # Locked achievements tab
        locked_frame = tk.Frame(notebook, bg='white')
        notebook.add(locked_frame, text=f"Locked ({len(achievements['locked'])})")
        
        # Display unlocked achievements
        if achievements['unlocked']:
            for achievement in achievements['unlocked']:
                ach_frame = tk.Frame(unlocked_frame, bg=COLORS["success"], relief='raised', borderwidth=1)
                ach_frame.pack(fill='x', padx=10, pady=5)
                
                tk.Label(ach_frame, text=f"★ {achievement[1]}", font=('Arial', 14, 'bold'),
                        bg=COLORS["success"], fg='white').pack(anchor='w', padx=10, pady=5)
                tk.Label(ach_frame, text=achievement[2], font=('Arial', 12),
                        bg=COLORS["success"], fg='white', wraplength=600).pack(anchor='w', padx=10, pady=5)
        else:
            tk.Label(unlocked_frame, text="No achievements unlocked yet!", 
                    font=('Arial', 14), bg='white', fg=COLORS["dark"]).pack(pady=50)
        
        # Display locked achievements
        if achievements['locked']:
            for achievement in achievements['locked']:
                ach_frame = tk.Frame(locked_frame, bg=COLORS["light"], relief='raised', borderwidth=1)
                ach_frame.pack(fill='x', padx=10, pady=5)
                
                tk.Label(ach_frame, text=f"🔒 {achievement[1]}", font=('Arial', 14),
                        bg=COLORS["light"], fg=COLORS["dark"]).pack(anchor='w', padx=10, pady=5)
                tk.Label(ach_frame, text=achievement[2], font=('Arial', 12),
                        bg=COLORS["light"], fg=COLORS["dark"], wraplength=600).pack(anchor='w', padx=10, pady=5)
        else:
            tk.Label(locked_frame, text="🎉 All achievements unlocked! 🎉", 
                    font=('Arial', 14, 'bold'), bg='white', fg=COLORS["success"]).pack(pady=50)
        
        # Back button
        back_frame = tk.Frame(achievements_content, bg='white')
        back_frame.pack(fill='x', pady=20)
        
        self.create_modern_button(back_frame, "⬅️ Back to Menu", self.show_age_selection,
                                bg_color=COLORS["primary"], font_size=12, width=15).pack()

# Make sure main.py uses this class
if __name__ == "__main__":
    root = tk.Tk()
    app = QuizApp(root)
    root.mainloop()
